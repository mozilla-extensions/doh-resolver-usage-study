const DOH_TEST_DOMAIN = "doh.test";
const WHOARTTHOU_DOMAIN = "whoartthou";
const CANONICAL_DOMAIN = "firefox-resolver-usage-test.net";

async function main() { 
  try {
    await browser.telemetry.registerEvents("test.test1.test2", {
      test1: {
        methods: ["test1"],
        objects: ["foobar"],
        extra_keys: [],
      },
    });
    await browser.telemetry.setEventRecordingEnabled("test.test1.test2", true);
    await browser.telemetry.recordEvent("test.test1.test2", "test1", "foobar");
  } catch(e) {console.log(e)}
  console.log(await browser.uuid.get());
}

main();
